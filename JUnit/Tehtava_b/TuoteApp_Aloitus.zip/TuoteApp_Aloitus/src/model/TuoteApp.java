package model;

public class TuoteApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TuoteTest test1 = new TuoteTest();
		test1.testSetHintaAlleNolla();
		test1.testSetHintaNollaTaiYliNolla();
	}

}
