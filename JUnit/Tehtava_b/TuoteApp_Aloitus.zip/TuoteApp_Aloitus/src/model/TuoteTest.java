package model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import org.junit.Assert;

class TuoteTest {

	@Test
	final void testSetHintaAlleNolla() {
		// Testitapaus t�h�n:
	}

	// Lis�� t�h�n uusia testitapauksia (metodeja):

}
