package henkilo;

public class HenkiloOhjelma {

	public static void main(String[] args) {
		Henkilo h1 = new Henkilo("Matti", "1993-01-01");
		System.out.println(h1);
		

	}

}
