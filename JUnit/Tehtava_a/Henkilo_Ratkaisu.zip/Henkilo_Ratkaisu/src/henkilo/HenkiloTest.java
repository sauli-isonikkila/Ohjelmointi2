package henkilo;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;

import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class HenkiloTest {

	@Test
	void testGetIka() {
		int ikaToTest = 30;	
		Henkilo h1 = createHenkiloWithIka(ikaToTest);
		Assert.assertTrue(h1.getIka() == ikaToTest);
		
		// fail("Not yet implemented");
	}

	private Henkilo createHenkiloWithIka(int ikaToTest) {
		int currentYear = LocalDate.now().getYear();	
		int syntVuosi = currentYear - ikaToTest;
		String syntPvm = syntVuosi + "-01-01";
		Henkilo h1 = new Henkilo("Matti", syntPvm);
		return h1;
	}

	@Test
	void testIs17YearOldIsNot18OrOlder() {
		Henkilo h1 = createHenkiloWithIka(17);
		Assert.assertFalse(h1.is18orOlder());	
	}

	
	@Test
	void testIs18YearOldIs18orOlder() {
		Henkilo h1 = createHenkiloWithIka(18);
		Assert.assertTrue(h1.is18orOlder());
	}


	@Test
	void testIs30YearOldIs18orOlder() {
		Henkilo h1 = createHenkiloWithIka(30);
		Assert.assertTrue(h1.is18orOlder());
	}
	
	// @Test(expected = NumberFormatException.class)
	@Test
	void testInvalidSyntPvmThrowsException() {
//      Huono tapa:
//		try {
//			@SuppressWarnings("unused")
//			Henkilo h1 = new Henkilo("Matti", "kelvoton-synttari-pvm");
//		} catch (NumberFormatException e) {
//			// T�m� on odotettua - ei tehd� mit��n
//			
//		} catch (Exception e) {
//			fail("Heitti eri poikkeuksen kuin odotettua!");
//		}
	
//		Parempi tapa:
		Assertions.assertThrows(NumberFormatException.class, () -> {
			@SuppressWarnings("unused")
			Henkilo h1 = new Henkilo("Matti", "kelvoton-synttari-pvm");
			
		});
	}
	
	@Test
	void testIsZeroYearsOldValidAge() {
		Henkilo h1 = createHenkiloWithIka(0);
		Assert.assertTrue(h1.isValidAge());
	}
	
	@Test
	void testIsMinus5YearsOldValidAge() {
		Henkilo h1 = createHenkiloWithIka(-5);
		Assert.assertFalse(h1.isValidAge());
	}	
}
